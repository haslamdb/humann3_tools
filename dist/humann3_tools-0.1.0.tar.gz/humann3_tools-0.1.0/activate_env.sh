#!/bin/bash
# Activate the humann3-tools conda environment
conda activate humann3-tools
