# src/humann3_tools/__init__.py
"""
HUMAnN3 Tools - A comprehensive toolkit for metagenomic analysis with HUMAnN3.
"""

__version__ = "0.1.0"